var annotated_dup =
[
    [ "stusb4500_ALERT_STATUS_1_MASK_bits_t", "structstusb4500___a_l_e_r_t___s_t_a_t_u_s__1___m_a_s_k__bits__t.html", "structstusb4500___a_l_e_r_t___s_t_a_t_u_s__1___m_a_s_k__bits__t" ],
    [ "stusb4500_ALERT_STATUS_1_MASK_t", "unionstusb4500___a_l_e_r_t___s_t_a_t_u_s__1___m_a_s_k__t.html", "unionstusb4500___a_l_e_r_t___s_t_a_t_u_s__1___m_a_s_k__t" ],
    [ "stusb4500_CC_STATUS_bits_t", "structstusb4500___c_c___s_t_a_t_u_s__bits__t.html", "structstusb4500___c_c___s_t_a_t_u_s__bits__t" ],
    [ "stusb4500_CC_STATUS_t", "unionstusb4500___c_c___s_t_a_t_u_s__t.html", "unionstusb4500___c_c___s_t_a_t_u_s__t" ],
    [ "stusb4500_pdo_flags_t", "structstusb4500__pdo__flags__t.html", "structstusb4500__pdo__flags__t" ],
    [ "stusb4500_pdo_raw_t", "unionstusb4500__pdo__raw__t.html", "unionstusb4500__pdo__raw__t" ],
    [ "stusb4500_pdo_t", "structstusb4500__pdo__t.html", "structstusb4500__pdo__t" ],
    [ "stusb4500_PORT_STATUS_0_bits_t", "structstusb4500___p_o_r_t___s_t_a_t_u_s__0__bits__t.html", "structstusb4500___p_o_r_t___s_t_a_t_u_s__0__bits__t" ],
    [ "stusb4500_PORT_STATUS_0_t", "unionstusb4500___p_o_r_t___s_t_a_t_u_s__0__t.html", "unionstusb4500___p_o_r_t___s_t_a_t_u_s__0__t" ],
    [ "stusb4500_PORT_STATUS_1_bits_t", "structstusb4500___p_o_r_t___s_t_a_t_u_s__1__bits__t.html", "structstusb4500___p_o_r_t___s_t_a_t_u_s__1__bits__t" ],
    [ "stusb4500_PORT_STATUS_1_t", "unionstusb4500___p_o_r_t___s_t_a_t_u_s__1__t.html", "unionstusb4500___p_o_r_t___s_t_a_t_u_s__1__t" ],
    [ "stusb4500_rdo_raw_t", "unionstusb4500__rdo__raw__t.html", "unionstusb4500__rdo__raw__t" ],
    [ "stusb4500_rdo_t", "structstusb4500__rdo__t.html", "structstusb4500__rdo__t" ],
    [ "stusb4500_usb_status_t", "structstusb4500__usb__status__t.html", "structstusb4500__usb__status__t" ]
];