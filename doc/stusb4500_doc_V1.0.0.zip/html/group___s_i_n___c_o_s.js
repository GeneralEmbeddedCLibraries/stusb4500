var group___s_i_n___c_o_s =
[
    [ "stusb4500_assemble_raw_pdo_frame", "group___s_i_n___c_o_s.html#gab31a5254aad02eb540dedeb34b83c486", null ],
    [ "stusb4500_clear_interrupts", "group___s_i_n___c_o_s.html#ga88a6cff789c29b0a1564493b61cc136b", null ],
    [ "stusb4500_parse_raw_pdo_frame", "group___s_i_n___c_o_s.html#ga9956fb2328ef8e39e27c8a08e438388c", null ],
    [ "stusb4500_parse_raw_rdo_frame", "group___s_i_n___c_o_s.html#gac55c065af33aaa6c01aee266f50c863c", null ],
    [ "stusb4500_ping_device", "group___s_i_n___c_o_s.html#ga00e70decf37d53f68d179979a121f7f7", null ],
    [ "stusb4500_read_device_id", "group___s_i_n___c_o_s.html#gae8b2b2f5b7395b5174db6f1862162db6", null ],
    [ "stusb4500_read_device_pdo", "group___s_i_n___c_o_s.html#ga7408399433e4b28752a526bb77c6c1ba", null ],
    [ "stusb4500_refresh_status", "group___s_i_n___c_o_s.html#gab4a1a7e9cc08d05a6f6e59b441cac145", null ],
    [ "stusb4500_reinit", "group___s_i_n___c_o_s.html#gaba38870e265ce46a048633f0d12996b3", null ],
    [ "stusb4500_set_interrupt_mask", "group___s_i_n___c_o_s.html#ga3efa8a174ccda47313213e2c7bc1bc55", null ],
    [ "stusb4500_soft_reset", "group___s_i_n___c_o_s.html#gaa312f7ec65e8cb5770dcaf98fa48b5da", null ],
    [ "stusb4500_write_device_pdo", "group___s_i_n___c_o_s.html#ga7edfb769d6c090dbf069d665834bc497", null ]
];