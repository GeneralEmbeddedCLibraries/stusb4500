var structstusb4500__pdo__t =
[
    [ "current", "group___s_t_u_s_b4500___a_p_i.html#gace48bf1f111051f831b1ac70c9b30527", null ],
    [ "fast_role_swap", "group___s_t_u_s_b4500___a_p_i.html#ga9077b24b79f0b0d97a2b6b4014b54b3d", null ],
    [ "flags", "group___s_t_u_s_b4500___a_p_i.html#ga7de8b4e416a47f587338878ac84e4c8f", null ],
    [ "num", "group___s_t_u_s_b4500___a_p_i.html#ga4c6fe85709f99cd7956932d4d6250a29", null ],
    [ "type", "group___s_t_u_s_b4500___a_p_i.html#ga9b22e5d62b8aa73a89b2083ffae292a6", null ],
    [ "voltage", "group___s_t_u_s_b4500___a_p_i.html#gacd34300d32c8303d473dead81facf2cd", null ]
];