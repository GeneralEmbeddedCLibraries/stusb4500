var stusb4500_8h =
[
    [ "stusb4500_attach_t", "group___s_t_u_s_b4500___a_p_i.html#ga7ebeeda2fec58a57d51a608fc2791204", [
      [ "eSTUSB4500_NOT_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204a7c3ace15e0bee93cf5a7a641eaf9fa81", null ],
      [ "eSTUSB4500_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204afe0c707e3084399f40a2223bcf9800bd", null ]
    ] ],
    [ "stusb4500_cc_stat_t", "group___s_t_u_s_b4500___a_p_i.html#ga5e62c05f28d7510c4fb7d0d8020fe898", [
      [ "eSTUSB4500_CC_STAT_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a86eac3f5286c92b377e964df1465bd55", null ],
      [ "eSTUSB4500_CC_STAT_DEFAULT", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a0fe01ebc1160bf1cdb71898f00d1255b", null ],
      [ "eSTUSB4500_CC_STAT_PWR_1_5", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a7862be7e369e5c8b21147432ed8dcd59", null ],
      [ "eSTUSB4500_CC_STAT_PWR_3_0", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a5b8bc3ed0e09479f06432691d3ed2d5f", null ]
    ] ],
    [ "stusb4500_pdo_num_t", "group___s_t_u_s_b4500___a_p_i.html#ga42892bb75d23e669a41ee25c84fe2f51", [
      [ "eSTUSB4500_PDO_1", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a38aeb14e96a21c3a9d69f3b128b49aab", null ],
      [ "eSTUSB4500_PDO_2", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a77eb56faeda3376a843587ad3f5b5445", null ],
      [ "eSTUSB4500_PDO_3", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a353bdb1b8d5bf26b84200b3b26217f43", null ],
      [ "eSTUSB4500_PDO_NUM_OF", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a750af1d974f4b02ecdb7b40e31ce3f08", null ]
    ] ],
    [ "stusb4500_pdo_type_t", "group___s_t_u_s_b4500___a_p_i.html#gac0dfc5a027265844f1e49b6657f38b36", [
      [ "eSTUSB4500_PDO_TYPE_FIXED_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a4f5abdf33171b71a3a1662bcdd671ff9", null ],
      [ "eSTUSB4500_PDO_TYPE_BATTERY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a7742f0ee1439f76f06060afeab2958b1", null ],
      [ "eSTUSB4500_PDO_TYPE_VARIABLE_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a9fcdfd76222e1384aa38b752103290d8", null ],
      [ "eSTUSB4500_PDO_TYPE_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36adf23222bd2a4c40e360dbeee488cfb12", null ]
    ] ],
    [ "stusb4500_rdo_mode_t", "group___s_t_u_s_b4500___a_p_i.html#ga6b71b78f5d76deaa2a48bf57fba60a1e", [
      [ "eSTUSB4500_RDO_MODE_USB_C", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea0630a52e7e88a1abc9bdc48f334552e4", null ],
      [ "eSTUSB4500_RDO_MODE_USB_PD", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea75ebffe0cc9b676323df8e6bb0f38d13", null ]
    ] ],
    [ "stusb4500_role_swap_t", "group___s_t_u_s_b4500___a_p_i.html#gab0f27c345921d21419b91701454cd65b", [
      [ "eSTUSB4500_ROLE_SWAP_NOT_SUPPORTED", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65bae3439c155638099f2ac92e0fe6df73f1", null ],
      [ "eSTUSB4500_ROLE_SWAP_DEFAULT_USB_POWER", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba1d0d38c6eb6cdf38baa02995ce6be974", null ],
      [ "eSTUSB4500_ROLE_SWAP_1_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba5937849a26d9a8db27ba439c18003f7c", null ],
      [ "eSTUSB4500_ROLE_SWAP_3_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65badbe318f02fbaec531ad043607ccb9ebd", null ]
    ] ],
    [ "stusb4500_status_t", "group___s_t_u_s_b4500___a_p_i.html#ga5de7e6065a42be35fe27c55217c437f7", [
      [ "eSTUSB4500_OK", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7af4f129608904f77335d3c808c4d4dc87", null ],
      [ "eSTUSB4500_ERROR", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7a2f82c6bb539997184cd50956e5db4326", null ]
    ] ],
    [ "stusb4500_get_status", "group___s_t_u_s_b4500___a_p_i.html#ga5eb7acdf4bd80b223c15fc1e271f7457", null ],
    [ "stusb4500_hndl", "group___s_t_u_s_b4500___a_p_i.html#ga2c97e5d2a8c45345df6ec900e924178a", null ],
    [ "stusb4500_init", "group___s_t_u_s_b4500___a_p_i.html#ga958cc607e9db5a1be737e8567acb9362", null ]
];