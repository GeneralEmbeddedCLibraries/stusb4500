var stusb4500__low__if_8h =
[
    [ "stusb4500_low_if_read_register", "group___s_t_u_s_b4500___l_o_w___i_f.html#ga44f91e852866fdef10f2374ae6de9b3d", null ],
    [ "stusb4500_low_if_write_register", "group___s_t_u_s_b4500___l_o_w___i_f.html#ga1f34b6ce18fd0b39d81a71736f6b029d", null ]
];