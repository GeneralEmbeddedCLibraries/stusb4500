var searchData=
[
  ['attach_0',['ATTACH',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga05f3eba2e42ab756a5a240e0795fac8f',1,'stusb4500_PORT_STATUS_1_bits_t']]],
  ['attach_5ftrans_1',['ATTACH_TRANS',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga8a34826a9180bca7b0420f96c99c17a2',1,'stusb4500_PORT_STATUS_0_bits_t']]],
  ['attached_2',['attached',['../group___s_t_u_s_b4500___a_p_i.html#ga2b6a9ffa49ab32ffd3b5c7bb224a6e56',1,'stusb4500_usb_status_t']]],
  ['attached_5fdevice_3',['ATTACHED_DEVICE',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga0cd7f8e9661158da48480a47e0006d69',1,'stusb4500_PORT_STATUS_1_bits_t']]]
];
