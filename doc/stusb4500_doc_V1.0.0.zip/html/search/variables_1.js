var searchData=
[
  ['b_236',['B',['../unionstusb4500__pdo__raw__t.html#a572eb602fa194adf0d55bba7d08386b1',1,'stusb4500_pdo_raw_t::B()'],['../unionstusb4500__rdo__raw__t.html#af73d9f1cb4f5bdf42f95457fe3f3a6c2',1,'stusb4500_rdo_raw_t::B()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga344f190562582c5cb0a469bd726e08c7',1,'stusb4500_ALERT_STATUS_1_MASK_t::B()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gad913340c033035c76077a6d678836afc',1,'stusb4500_PORT_STATUS_0_t::B()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga82c5ec42f8e8179c7e19c2c7d57af513',1,'stusb4500_PORT_STATUS_1_t::B()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gab62e3dcf17fec2b167afe0f59aae4481',1,'stusb4500_CC_STATUS_t::B()']]]
];
