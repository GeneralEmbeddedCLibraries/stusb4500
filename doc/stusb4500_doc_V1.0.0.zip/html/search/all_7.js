var searchData=
[
  ['high_5fcapability_116',['high_capability',['../unionstusb4500__pdo__raw__t.html#a0d7cad0549b6aaac9145a6cad82d6fa1',1,'stusb4500_pdo_raw_t::high_capability()'],['../group___s_t_u_s_b4500___a_p_i.html#gadb13ea28025efcb213ce66d343d6462d',1,'stusb4500_pdo_flags_t::high_capability()']]]
];
