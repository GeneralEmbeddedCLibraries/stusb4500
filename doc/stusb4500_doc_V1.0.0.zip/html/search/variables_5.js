var searchData=
[
  ['fast_5frole_252',['fast_role',['../unionstusb4500__pdo__raw__t.html#acec7182845705ec87fb859d784684a79',1,'stusb4500_pdo_raw_t']]],
  ['fast_5frole_5fswap_253',['fast_role_swap',['../group___s_t_u_s_b4500___a_p_i.html#ga9077b24b79f0b0d97a2b6b4014b54b3d',1,'stusb4500_pdo_t']]],
  ['flags_254',['flags',['../group___s_t_u_s_b4500___a_p_i.html#ga7de8b4e416a47f587338878ac84e4c8f',1,'stusb4500_pdo_t']]]
];
