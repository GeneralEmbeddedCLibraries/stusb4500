var searchData=
[
  ['data_5fmode_247',['DATA_MODE',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gaf09d7785f1440e3b220a0a82db4b1dec',1,'stusb4500_PORT_STATUS_1_bits_t']]],
  ['dual_5frole_5fdata_248',['dual_role_data',['../unionstusb4500__pdo__raw__t.html#a40b1414df3c65e648cd6509c2566d8eb',1,'stusb4500_pdo_raw_t::dual_role_data()'],['../group___s_t_u_s_b4500___a_p_i.html#ga12b34be2a7d5e94b5c4a09f907b6aa1f',1,'stusb4500_pdo_flags_t::dual_role_data()']]],
  ['dual_5frole_5fpower_249',['dual_role_power',['../group___s_t_u_s_b4500___a_p_i.html#gabf4be52deb6d8f70b05a6469145319fb',1,'stusb4500_pdo_flags_t']]],
  ['dual_5frole_5fpwr_250',['dual_role_pwr',['../unionstusb4500__pdo__raw__t.html#aed6c2030c050c36b99ea13e6e79c80f2',1,'stusb4500_pdo_raw_t']]]
];
