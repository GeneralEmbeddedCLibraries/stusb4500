var structstusb4500__usb__status__t =
[
    [ "attached", "group___s_t_u_s_b4500___a_p_i.html#ga2b6a9ffa49ab32ffd3b5c7bb224a6e56", null ],
    [ "CC1", "group___s_t_u_s_b4500___a_p_i.html#ga9a45374c9ab32f46c91798eb258d4cef", null ],
    [ "CC2", "group___s_t_u_s_b4500___a_p_i.html#gaeda5cec92bfdccab77ab0e1b785efc3b", null ],
    [ "RDO", "group___s_t_u_s_b4500___a_p_i.html#gaea939e61b8e4fbe0f8faad0f2cd6d106", null ]
];