var group___s_t_u_s_b4500___a_p_i =
[
    [ "stusb4500_pdo_raw_t", "unionstusb4500__pdo__raw__t.html", [
      [ "B", "unionstusb4500__pdo__raw__t.html#a572eb602fa194adf0d55bba7d08386b1", null ],
      [ "current", "unionstusb4500__pdo__raw__t.html#a4dc52c253cdc9c0d832a6221d7c4c330", null ],
      [ "dual_role_data", "unionstusb4500__pdo__raw__t.html#a40b1414df3c65e648cd6509c2566d8eb", null ],
      [ "dual_role_pwr", "unionstusb4500__pdo__raw__t.html#aed6c2030c050c36b99ea13e6e79c80f2", null ],
      [ "fast_role", "unionstusb4500__pdo__raw__t.html#acec7182845705ec87fb859d784684a79", null ],
      [ "high_capability", "unionstusb4500__pdo__raw__t.html#a0d7cad0549b6aaac9145a6cad82d6fa1", null ],
      [ "I", "unionstusb4500__pdo__raw__t.html#a0a74dacc00b3233b8ec9f514f6aab48c", null ],
      [ "reserved", "unionstusb4500__pdo__raw__t.html#a2434adc1f02588fb5ac7644ab3baada8", null ],
      [ "type", "unionstusb4500__pdo__raw__t.html#aacb0eaeeb0ba4395f1f32a2939d69540", null ],
      [ "U", "unionstusb4500__pdo__raw__t.html#a7d43f75c6156710ca196114d7ed81d88", null ],
      [ "unconstrained_pwr", "unionstusb4500__pdo__raw__t.html#ac1ed72d0a194c967b19603ce54be57bd", null ],
      [ "USB_com_en", "unionstusb4500__pdo__raw__t.html#a5c65df506d301813cb2ba9d4ca724057", null ],
      [ "voltage", "unionstusb4500__pdo__raw__t.html#afe1ce08dd38abe73eaac5809e15d1934", null ]
    ] ],
    [ "stusb4500_rdo_raw_t", "unionstusb4500__rdo__raw__t.html", [
      [ "B", "unionstusb4500__rdo__raw__t.html#af73d9f1cb4f5bdf42f95457fe3f3a6c2", null ],
      [ "capability_mismatched", "unionstusb4500__rdo__raw__t.html#a44ae836c7360ec466a12fa11168c2bb6", null ],
      [ "current_max", "unionstusb4500__rdo__raw__t.html#ac060890e9abdd3626e45614fdabb8317", null ],
      [ "current_operating", "unionstusb4500__rdo__raw__t.html#a13e172c30553604733af62bec5d988c0", null ],
      [ "extend_msg_support", "unionstusb4500__rdo__raw__t.html#a463c881330d9182136612e48cbf6ef4c", null ],
      [ "give_back_flag", "unionstusb4500__rdo__raw__t.html#a629f26a8e8c71f4795e78cd3349f7f0d", null ],
      [ "I", "unionstusb4500__rdo__raw__t.html#a4e5b493246ada6b285983a0039a6a2ab", null ],
      [ "no_usb_suspend", "unionstusb4500__rdo__raw__t.html#aff3956ccacd0f60c3fe8c982178c1721", null ],
      [ "object_position", "unionstusb4500__rdo__raw__t.html#a1c24c6fdb017b83ad103f1b1283927ca", null ],
      [ "reserved", "unionstusb4500__rdo__raw__t.html#a997baadb7b47c896a525e0c30192b8bd", null ],
      [ "reserved2", "unionstusb4500__rdo__raw__t.html#af2b319352ccae5d31166e8c6c4a6100d", null ],
      [ "U", "unionstusb4500__rdo__raw__t.html#a4f564ffd79571decfeafbd8855deb402", null ],
      [ "usb_com_capable", "unionstusb4500__rdo__raw__t.html#ac1acd0fe84c415e446c62e7c3ccf8a41", null ]
    ] ],
    [ "stusb4500_pdo_flags_t", "structstusb4500__pdo__flags__t.html", [
      [ "dual_role_data", "group___s_t_u_s_b4500___a_p_i.html#ga12b34be2a7d5e94b5c4a09f907b6aa1f", null ],
      [ "dual_role_power", "group___s_t_u_s_b4500___a_p_i.html#gabf4be52deb6d8f70b05a6469145319fb", null ],
      [ "high_capability", "group___s_t_u_s_b4500___a_p_i.html#gadb13ea28025efcb213ce66d343d6462d", null ],
      [ "reserved", "group___s_t_u_s_b4500___a_p_i.html#ga4d8ec95df0f4922eeef722ff0134baf2", null ],
      [ "unconstrained_power", "group___s_t_u_s_b4500___a_p_i.html#ga20b83b74f189276e9a7de3c9b0616ff5", null ],
      [ "USB_com_enable", "group___s_t_u_s_b4500___a_p_i.html#gacda7fd9650153d930d292142431ac7d1", null ]
    ] ],
    [ "stusb4500_pdo_t", "structstusb4500__pdo__t.html", [
      [ "current", "group___s_t_u_s_b4500___a_p_i.html#gace48bf1f111051f831b1ac70c9b30527", null ],
      [ "fast_role_swap", "group___s_t_u_s_b4500___a_p_i.html#ga9077b24b79f0b0d97a2b6b4014b54b3d", null ],
      [ "flags", "group___s_t_u_s_b4500___a_p_i.html#ga7de8b4e416a47f587338878ac84e4c8f", null ],
      [ "num", "group___s_t_u_s_b4500___a_p_i.html#ga4c6fe85709f99cd7956932d4d6250a29", null ],
      [ "type", "group___s_t_u_s_b4500___a_p_i.html#ga9b22e5d62b8aa73a89b2083ffae292a6", null ],
      [ "voltage", "group___s_t_u_s_b4500___a_p_i.html#gacd34300d32c8303d473dead81facf2cd", null ]
    ] ],
    [ "stusb4500_rdo_t", "structstusb4500__rdo__t.html", [
      [ "current", "group___s_t_u_s_b4500___a_p_i.html#ga5cc179e92808f8b3acbcab57f0fa5f5f", null ],
      [ "maximum", "group___s_t_u_s_b4500___a_p_i.html#ga638899e46b757731c7f43faabfbbbfab", null ],
      [ "mode", "group___s_t_u_s_b4500___a_p_i.html#gae4075f842663ec845d8bb5637065094c", null ],
      [ "operating", "group___s_t_u_s_b4500___a_p_i.html#gaf6c143ee307f4234f8d838134535f13d", null ],
      [ "src_pdo", "group___s_t_u_s_b4500___a_p_i.html#ga7b11fca00d433e44e6d647e896d1c85b", null ]
    ] ],
    [ "stusb4500_usb_status_t", "structstusb4500__usb__status__t.html", [
      [ "attached", "group___s_t_u_s_b4500___a_p_i.html#ga2b6a9ffa49ab32ffd3b5c7bb224a6e56", null ],
      [ "CC1", "group___s_t_u_s_b4500___a_p_i.html#ga9a45374c9ab32f46c91798eb258d4cef", null ],
      [ "CC2", "group___s_t_u_s_b4500___a_p_i.html#gaeda5cec92bfdccab77ab0e1b785efc3b", null ],
      [ "RDO", "group___s_t_u_s_b4500___a_p_i.html#gaea939e61b8e4fbe0f8faad0f2cd6d106", null ]
    ] ],
    [ "STUSB4500_CONVERT_CURRENT_TO_A", "group___s_t_u_s_b4500___a_p_i.html#ga7bf0b0c9569e488d49ef2d36b1e69610", null ],
    [ "STUSB4500_CONVERT_CURRENT_TO_RAW", "group___s_t_u_s_b4500___a_p_i.html#gaab546740f0eee3522af00d7642e3dc9c", null ],
    [ "STUSB4500_CONVERT_VOLTAGE_TO_RAW", "group___s_t_u_s_b4500___a_p_i.html#ga78973a84e0cf83698c0085b991eb14fb", null ],
    [ "STUSB4500_CONVERT_VOLTAGE_TO_V", "group___s_t_u_s_b4500___a_p_i.html#gad338a808f4bb1f1f5fa875773708019b", null ],
    [ "stusb4500_attach_t", "group___s_t_u_s_b4500___a_p_i.html#ga7ebeeda2fec58a57d51a608fc2791204", [
      [ "eSTUSB4500_NOT_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204a7c3ace15e0bee93cf5a7a641eaf9fa81", null ],
      [ "eSTUSB4500_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204afe0c707e3084399f40a2223bcf9800bd", null ]
    ] ],
    [ "stusb4500_cc_stat_t", "group___s_t_u_s_b4500___a_p_i.html#ga5e62c05f28d7510c4fb7d0d8020fe898", [
      [ "eSTUSB4500_CC_STAT_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a86eac3f5286c92b377e964df1465bd55", null ],
      [ "eSTUSB4500_CC_STAT_DEFAULT", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a0fe01ebc1160bf1cdb71898f00d1255b", null ],
      [ "eSTUSB4500_CC_STAT_PWR_1_5", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a7862be7e369e5c8b21147432ed8dcd59", null ],
      [ "eSTUSB4500_CC_STAT_PWR_3_0", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a5b8bc3ed0e09479f06432691d3ed2d5f", null ]
    ] ],
    [ "stusb4500_pdo_num_t", "group___s_t_u_s_b4500___a_p_i.html#ga42892bb75d23e669a41ee25c84fe2f51", [
      [ "eSTUSB4500_PDO_1", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a38aeb14e96a21c3a9d69f3b128b49aab", null ],
      [ "eSTUSB4500_PDO_2", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a77eb56faeda3376a843587ad3f5b5445", null ],
      [ "eSTUSB4500_PDO_3", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a353bdb1b8d5bf26b84200b3b26217f43", null ],
      [ "eSTUSB4500_PDO_NUM_OF", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a750af1d974f4b02ecdb7b40e31ce3f08", null ]
    ] ],
    [ "stusb4500_pdo_type_t", "group___s_t_u_s_b4500___a_p_i.html#gac0dfc5a027265844f1e49b6657f38b36", [
      [ "eSTUSB4500_PDO_TYPE_FIXED_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a4f5abdf33171b71a3a1662bcdd671ff9", null ],
      [ "eSTUSB4500_PDO_TYPE_BATTERY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a7742f0ee1439f76f06060afeab2958b1", null ],
      [ "eSTUSB4500_PDO_TYPE_VARIABLE_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a9fcdfd76222e1384aa38b752103290d8", null ],
      [ "eSTUSB4500_PDO_TYPE_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36adf23222bd2a4c40e360dbeee488cfb12", null ]
    ] ],
    [ "stusb4500_rdo_mode_t", "group___s_t_u_s_b4500___a_p_i.html#ga6b71b78f5d76deaa2a48bf57fba60a1e", [
      [ "eSTUSB4500_RDO_MODE_USB_C", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea0630a52e7e88a1abc9bdc48f334552e4", null ],
      [ "eSTUSB4500_RDO_MODE_USB_PD", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea75ebffe0cc9b676323df8e6bb0f38d13", null ]
    ] ],
    [ "stusb4500_role_swap_t", "group___s_t_u_s_b4500___a_p_i.html#gab0f27c345921d21419b91701454cd65b", [
      [ "eSTUSB4500_ROLE_SWAP_NOT_SUPPORTED", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65bae3439c155638099f2ac92e0fe6df73f1", null ],
      [ "eSTUSB4500_ROLE_SWAP_DEFAULT_USB_POWER", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba1d0d38c6eb6cdf38baa02995ce6be974", null ],
      [ "eSTUSB4500_ROLE_SWAP_1_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba5937849a26d9a8db27ba439c18003f7c", null ],
      [ "eSTUSB4500_ROLE_SWAP_3_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65badbe318f02fbaec531ad043607ccb9ebd", null ]
    ] ],
    [ "stusb4500_status_t", "group___s_t_u_s_b4500___a_p_i.html#ga5de7e6065a42be35fe27c55217c437f7", [
      [ "eSTUSB4500_OK", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7af4f129608904f77335d3c808c4d4dc87", null ],
      [ "eSTUSB4500_ERROR", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7a2f82c6bb539997184cd50956e5db4326", null ]
    ] ],
    [ "eSTUSB4500_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204afe0c707e3084399f40a2223bcf9800bd", null ],
    [ "eSTUSB4500_CC_STAT_DEFAULT", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a0fe01ebc1160bf1cdb71898f00d1255b", null ],
    [ "eSTUSB4500_CC_STAT_PWR_1_5", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a7862be7e369e5c8b21147432ed8dcd59", null ],
    [ "eSTUSB4500_CC_STAT_PWR_3_0", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a5b8bc3ed0e09479f06432691d3ed2d5f", null ],
    [ "eSTUSB4500_CC_STAT_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#gga5e62c05f28d7510c4fb7d0d8020fe898a86eac3f5286c92b377e964df1465bd55", null ],
    [ "eSTUSB4500_ERROR", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7a2f82c6bb539997184cd50956e5db4326", null ],
    [ "eSTUSB4500_NOT_ATTACHED", "group___s_t_u_s_b4500___a_p_i.html#gga7ebeeda2fec58a57d51a608fc2791204a7c3ace15e0bee93cf5a7a641eaf9fa81", null ],
    [ "eSTUSB4500_OK", "group___s_t_u_s_b4500___a_p_i.html#gga5de7e6065a42be35fe27c55217c437f7af4f129608904f77335d3c808c4d4dc87", null ],
    [ "eSTUSB4500_PDO_1", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a38aeb14e96a21c3a9d69f3b128b49aab", null ],
    [ "eSTUSB4500_PDO_2", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a77eb56faeda3376a843587ad3f5b5445", null ],
    [ "eSTUSB4500_PDO_3", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a353bdb1b8d5bf26b84200b3b26217f43", null ],
    [ "eSTUSB4500_PDO_NUM_OF", "group___s_t_u_s_b4500___a_p_i.html#gga42892bb75d23e669a41ee25c84fe2f51a750af1d974f4b02ecdb7b40e31ce3f08", null ],
    [ "eSTUSB4500_PDO_TYPE_BATTERY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a7742f0ee1439f76f06060afeab2958b1", null ],
    [ "eSTUSB4500_PDO_TYPE_FIXED_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a4f5abdf33171b71a3a1662bcdd671ff9", null ],
    [ "eSTUSB4500_PDO_TYPE_RESERVED", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36adf23222bd2a4c40e360dbeee488cfb12", null ],
    [ "eSTUSB4500_PDO_TYPE_VARIABLE_SUPPLY", "group___s_t_u_s_b4500___a_p_i.html#ggac0dfc5a027265844f1e49b6657f38b36a9fcdfd76222e1384aa38b752103290d8", null ],
    [ "eSTUSB4500_RDO_MODE_USB_C", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea0630a52e7e88a1abc9bdc48f334552e4", null ],
    [ "eSTUSB4500_RDO_MODE_USB_PD", "group___s_t_u_s_b4500___a_p_i.html#gga6b71b78f5d76deaa2a48bf57fba60a1ea75ebffe0cc9b676323df8e6bb0f38d13", null ],
    [ "eSTUSB4500_ROLE_SWAP_1_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba5937849a26d9a8db27ba439c18003f7c", null ],
    [ "eSTUSB4500_ROLE_SWAP_3_5A_5V", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65badbe318f02fbaec531ad043607ccb9ebd", null ],
    [ "eSTUSB4500_ROLE_SWAP_DEFAULT_USB_POWER", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65ba1d0d38c6eb6cdf38baa02995ce6be974", null ],
    [ "eSTUSB4500_ROLE_SWAP_NOT_SUPPORTED", "group___s_t_u_s_b4500___a_p_i.html#ggab0f27c345921d21419b91701454cd65bae3439c155638099f2ac92e0fe6df73f1", null ],
    [ "stusb4500_get_status", "group___s_t_u_s_b4500___a_p_i.html#ga5eb7acdf4bd80b223c15fc1e271f7457", null ],
    [ "stusb4500_hndl", "group___s_t_u_s_b4500___a_p_i.html#ga2c97e5d2a8c45345df6ec900e924178a", null ],
    [ "stusb4500_init", "group___s_t_u_s_b4500___a_p_i.html#ga958cc607e9db5a1be737e8567acb9362", null ],
    [ "attached", "group___s_t_u_s_b4500___a_p_i.html#ga2b6a9ffa49ab32ffd3b5c7bb224a6e56", null ],
    [ "CC1", "group___s_t_u_s_b4500___a_p_i.html#ga9a45374c9ab32f46c91798eb258d4cef", null ],
    [ "CC2", "group___s_t_u_s_b4500___a_p_i.html#gaeda5cec92bfdccab77ab0e1b785efc3b", null ],
    [ "current", "group___s_t_u_s_b4500___a_p_i.html#gace48bf1f111051f831b1ac70c9b30527", null ],
    [ "current", "group___s_t_u_s_b4500___a_p_i.html#ga5cc179e92808f8b3acbcab57f0fa5f5f", null ],
    [ "dual_role_data", "group___s_t_u_s_b4500___a_p_i.html#ga12b34be2a7d5e94b5c4a09f907b6aa1f", null ],
    [ "dual_role_power", "group___s_t_u_s_b4500___a_p_i.html#gabf4be52deb6d8f70b05a6469145319fb", null ],
    [ "fast_role_swap", "group___s_t_u_s_b4500___a_p_i.html#ga9077b24b79f0b0d97a2b6b4014b54b3d", null ],
    [ "flags", "group___s_t_u_s_b4500___a_p_i.html#ga7de8b4e416a47f587338878ac84e4c8f", null ],
    [ "g_PDO", "group___s_t_u_s_b4500___a_p_i.html#gaf508e55f0117c6fffece141186f7dea8", null ],
    [ "g_stusb4500_status", "group___s_t_u_s_b4500___a_p_i.html#ga32cc3fcf354d8bacc9ec7a6d49a2e4fd", null ],
    [ "gb_is_init", "group___s_t_u_s_b4500___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "high_capability", "group___s_t_u_s_b4500___a_p_i.html#gadb13ea28025efcb213ce66d343d6462d", null ],
    [ "maximum", "group___s_t_u_s_b4500___a_p_i.html#ga638899e46b757731c7f43faabfbbbfab", null ],
    [ "maximum", "group___s_t_u_s_b4500___a_p_i.html#ga52a551efa9b25c581663206f254e5864", null ],
    [ "mode", "group___s_t_u_s_b4500___a_p_i.html#gae4075f842663ec845d8bb5637065094c", null ],
    [ "num", "group___s_t_u_s_b4500___a_p_i.html#ga4c6fe85709f99cd7956932d4d6250a29", null ],
    [ "operating", "group___s_t_u_s_b4500___a_p_i.html#gaf6c143ee307f4234f8d838134535f13d", null ],
    [ "operating", "group___s_t_u_s_b4500___a_p_i.html#gabdbf901ca098cc53bfde205c9c945f18", null ],
    [ "RDO", "group___s_t_u_s_b4500___a_p_i.html#gaea939e61b8e4fbe0f8faad0f2cd6d106", null ],
    [ "reserved", "group___s_t_u_s_b4500___a_p_i.html#ga4d8ec95df0f4922eeef722ff0134baf2", null ],
    [ "src_pdo", "group___s_t_u_s_b4500___a_p_i.html#ga7b11fca00d433e44e6d647e896d1c85b", null ],
    [ "type", "group___s_t_u_s_b4500___a_p_i.html#ga9b22e5d62b8aa73a89b2083ffae292a6", null ],
    [ "unconstrained_power", "group___s_t_u_s_b4500___a_p_i.html#ga20b83b74f189276e9a7de3c9b0616ff5", null ],
    [ "USB_com_enable", "group___s_t_u_s_b4500___a_p_i.html#gacda7fd9650153d930d292142431ac7d1", null ],
    [ "voltage", "group___s_t_u_s_b4500___a_p_i.html#gacd34300d32c8303d473dead81facf2cd", null ]
];