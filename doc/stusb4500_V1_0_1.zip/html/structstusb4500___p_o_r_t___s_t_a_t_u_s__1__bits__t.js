var structstusb4500___p_o_r_t___s_t_a_t_u_s__1__bits__t =
[
    [ "ATTACH", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga05f3eba2e42ab756a5a240e0795fac8f", null ],
    [ "ATTACHED_DEVICE", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga0cd7f8e9661158da48480a47e0006d69", null ],
    [ "DATA_MODE", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gaf09d7785f1440e3b220a0a82db4b1dec", null ],
    [ "POWER_MODE", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gaf1463f035b66c7d1be3d10b51ed4f41a", null ],
    [ "reserved", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga11ffe8582d6d56f305c8716b849ea257", null ]
];