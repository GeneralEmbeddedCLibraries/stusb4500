var structstusb4500___p_o_r_t___s_t_a_t_u_s__0__bits__t =
[
    [ "ATTACH_TRANS", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga8a34826a9180bca7b0420f96c99c17a2", null ],
    [ "reserved", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gabd7750354f1e584cf938022aef5478e8", null ]
];