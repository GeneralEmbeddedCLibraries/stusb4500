var structstusb4500___c_c___s_t_a_t_u_s__bits__t =
[
    [ "CC1_STATE", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gac051d41f3ad7dcae0b974b0ca1099256", null ],
    [ "CC2_STATE", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga549f7667621e865d4657901705551cfb", null ],
    [ "CONNECT_RESULT", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga00ee4a848183bb13930859fed27faa83", null ],
    [ "LOCKING_4_CONNECTION", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gad74b82b3e49153ab3b7d9fea4cf12ba6", null ],
    [ "reserved", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gaf39a189540affc6cc270203ec1df2881", null ]
];