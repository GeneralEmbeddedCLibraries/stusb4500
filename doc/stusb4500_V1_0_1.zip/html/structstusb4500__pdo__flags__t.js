var structstusb4500__pdo__flags__t =
[
    [ "dual_role_data", "group___s_t_u_s_b4500___a_p_i.html#ga12b34be2a7d5e94b5c4a09f907b6aa1f", null ],
    [ "dual_role_power", "group___s_t_u_s_b4500___a_p_i.html#gabf4be52deb6d8f70b05a6469145319fb", null ],
    [ "high_capability", "group___s_t_u_s_b4500___a_p_i.html#gadb13ea28025efcb213ce66d343d6462d", null ],
    [ "reserved", "group___s_t_u_s_b4500___a_p_i.html#ga4d8ec95df0f4922eeef722ff0134baf2", null ],
    [ "unconstrained_power", "group___s_t_u_s_b4500___a_p_i.html#ga20b83b74f189276e9a7de3c9b0616ff5", null ],
    [ "USB_com_enable", "group___s_t_u_s_b4500___a_p_i.html#gacda7fd9650153d930d292142431ac7d1", null ]
];