var searchData=
[
  ['capability_5fmismatched_240',['capability_mismatched',['../unionstusb4500__rdo__raw__t.html#a44ae836c7360ec466a12fa11168c2bb6',1,'stusb4500_rdo_raw_t']]],
  ['cc1_241',['CC1',['../group___s_t_u_s_b4500___a_p_i.html#ga9a45374c9ab32f46c91798eb258d4cef',1,'stusb4500_usb_status_t']]],
  ['cc1_5fstate_242',['CC1_STATE',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gac051d41f3ad7dcae0b974b0ca1099256',1,'stusb4500_CC_STATUS_bits_t']]],
  ['cc2_243',['CC2',['../group___s_t_u_s_b4500___a_p_i.html#gaeda5cec92bfdccab77ab0e1b785efc3b',1,'stusb4500_usb_status_t']]],
  ['cc2_5fstate_244',['CC2_STATE',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga549f7667621e865d4657901705551cfb',1,'stusb4500_CC_STATUS_bits_t']]],
  ['cc_5ffault_5fstatus_5fal_5fmask_245',['CC_FAULT_STATUS_AL_MASK',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga406458faeffbe4f02afe7712d6e19dda',1,'stusb4500_ALERT_STATUS_1_MASK_bits_t']]],
  ['connect_5fresult_246',['CONNECT_RESULT',['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga00ee4a848183bb13930859fed27faa83',1,'stusb4500_CC_STATUS_bits_t']]],
  ['current_247',['current',['../unionstusb4500__pdo__raw__t.html#a4dc52c253cdc9c0d832a6221d7c4c330',1,'stusb4500_pdo_raw_t::current()'],['../group___s_t_u_s_b4500___a_p_i.html#gace48bf1f111051f831b1ac70c9b30527',1,'stusb4500_pdo_t::current()'],['../group___s_t_u_s_b4500___a_p_i.html#ga5cc179e92808f8b3acbcab57f0fa5f5f',1,'stusb4500_rdo_t::current()']]],
  ['current_5fmax_248',['current_max',['../unionstusb4500__rdo__raw__t.html#ac060890e9abdd3626e45614fdabb8317',1,'stusb4500_rdo_raw_t']]],
  ['current_5foperating_249',['current_operating',['../unionstusb4500__rdo__raw__t.html#a13e172c30553604733af62bec5d988c0',1,'stusb4500_rdo_raw_t']]]
];
