var searchData=
[
  ['g_5fpdo_112',['g_PDO',['../group___s_t_u_s_b4500___a_p_i.html#gaf508e55f0117c6fffece141186f7dea8',1,'stusb4500.c']]],
  ['g_5fstusb4500_5fstatus_113',['g_stusb4500_status',['../group___s_t_u_s_b4500___a_p_i.html#ga32cc3fcf354d8bacc9ec7a6d49a2e4fd',1,'stusb4500.c']]],
  ['gb_5fis_5finit_114',['gb_is_init',['../group___s_t_u_s_b4500___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385',1,'stusb4500.c']]],
  ['give_5fback_5fflag_115',['give_back_flag',['../unionstusb4500__rdo__raw__t.html#a629f26a8e8c71f4795e78cd3349f7f0d',1,'stusb4500_rdo_raw_t']]]
];
