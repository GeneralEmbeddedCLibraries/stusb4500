var searchData=
[
  ['no_5fusb_5fsuspend_121',['no_usb_suspend',['../unionstusb4500__rdo__raw__t.html#aff3956ccacd0f60c3fe8c982178c1721',1,'stusb4500_rdo_raw_t']]],
  ['num_122',['num',['../group___s_t_u_s_b4500___a_p_i.html#ga4c6fe85709f99cd7956932d4d6250a29',1,'stusb4500_pdo_t']]]
];
