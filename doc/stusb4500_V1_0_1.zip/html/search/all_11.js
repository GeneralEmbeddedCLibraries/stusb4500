var searchData=
[
  ['u_192',['U',['../unionstusb4500__pdo__raw__t.html#a7d43f75c6156710ca196114d7ed81d88',1,'stusb4500_pdo_raw_t::U()'],['../unionstusb4500__rdo__raw__t.html#a4f564ffd79571decfeafbd8855deb402',1,'stusb4500_rdo_raw_t::U()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga086619ca149a364786dd4561694c5d69',1,'stusb4500_ALERT_STATUS_1_MASK_t::U()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga0aba0950dc897c8dc36b53e2e13cd705',1,'stusb4500_PORT_STATUS_0_t::U()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gaee57ab54dd3e5a532b5fe677dee6e719',1,'stusb4500_PORT_STATUS_1_t::U()'],['../group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga93f24c470b9fcf0b4caa6384df151d00',1,'stusb4500_CC_STATUS_t::U()']]],
  ['unconstrained_5fpower_193',['unconstrained_power',['../group___s_t_u_s_b4500___a_p_i.html#ga20b83b74f189276e9a7de3c9b0616ff5',1,'stusb4500_pdo_flags_t']]],
  ['unconstrained_5fpwr_194',['unconstrained_pwr',['../unionstusb4500__pdo__raw__t.html#ac1ed72d0a194c967b19603ce54be57bd',1,'stusb4500_pdo_raw_t']]],
  ['usb_5fcom_5fcapable_195',['usb_com_capable',['../unionstusb4500__rdo__raw__t.html#ac1acd0fe84c415e446c62e7c3ccf8a41',1,'stusb4500_rdo_raw_t']]],
  ['usb_5fcom_5fen_196',['USB_com_en',['../unionstusb4500__pdo__raw__t.html#a5c65df506d301813cb2ba9d4ca724057',1,'stusb4500_pdo_raw_t']]],
  ['usb_5fcom_5fenable_197',['USB_com_enable',['../group___s_t_u_s_b4500___a_p_i.html#gacda7fd9650153d930d292142431ac7d1',1,'stusb4500_pdo_flags_t']]]
];
