var searchData=
[
  ['voltage_287',['voltage',['../unionstusb4500__pdo__raw__t.html#afe1ce08dd38abe73eaac5809e15d1934',1,'stusb4500_pdo_raw_t::voltage()'],['../group___s_t_u_s_b4500___a_p_i.html#gacd34300d32c8303d473dead81facf2cd',1,'stusb4500_pdo_t::voltage()']]]
];
