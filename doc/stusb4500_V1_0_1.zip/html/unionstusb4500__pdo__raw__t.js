var unionstusb4500__pdo__raw__t =
[
    [ "B", "unionstusb4500__pdo__raw__t.html#a572eb602fa194adf0d55bba7d08386b1", null ],
    [ "current", "unionstusb4500__pdo__raw__t.html#a4dc52c253cdc9c0d832a6221d7c4c330", null ],
    [ "dual_role_data", "unionstusb4500__pdo__raw__t.html#a40b1414df3c65e648cd6509c2566d8eb", null ],
    [ "dual_role_pwr", "unionstusb4500__pdo__raw__t.html#aed6c2030c050c36b99ea13e6e79c80f2", null ],
    [ "fast_role", "unionstusb4500__pdo__raw__t.html#acec7182845705ec87fb859d784684a79", null ],
    [ "high_capability", "unionstusb4500__pdo__raw__t.html#a0d7cad0549b6aaac9145a6cad82d6fa1", null ],
    [ "I", "unionstusb4500__pdo__raw__t.html#a0a74dacc00b3233b8ec9f514f6aab48c", null ],
    [ "reserved", "unionstusb4500__pdo__raw__t.html#a2434adc1f02588fb5ac7644ab3baada8", null ],
    [ "type", "unionstusb4500__pdo__raw__t.html#aacb0eaeeb0ba4395f1f32a2939d69540", null ],
    [ "U", "unionstusb4500__pdo__raw__t.html#a7d43f75c6156710ca196114d7ed81d88", null ],
    [ "unconstrained_pwr", "unionstusb4500__pdo__raw__t.html#ac1ed72d0a194c967b19603ce54be57bd", null ],
    [ "USB_com_en", "unionstusb4500__pdo__raw__t.html#a5c65df506d301813cb2ba9d4ca724057", null ],
    [ "voltage", "unionstusb4500__pdo__raw__t.html#afe1ce08dd38abe73eaac5809e15d1934", null ]
];