var structstusb4500__rdo__t =
[
    [ "current", "group___s_t_u_s_b4500___a_p_i.html#ga5cc179e92808f8b3acbcab57f0fa5f5f", null ],
    [ "maximum", "group___s_t_u_s_b4500___a_p_i.html#ga638899e46b757731c7f43faabfbbbfab", null ],
    [ "mode", "group___s_t_u_s_b4500___a_p_i.html#gae4075f842663ec845d8bb5637065094c", null ],
    [ "operating", "group___s_t_u_s_b4500___a_p_i.html#gaf6c143ee307f4234f8d838134535f13d", null ],
    [ "src_pdo", "group___s_t_u_s_b4500___a_p_i.html#ga7b11fca00d433e44e6d647e896d1c85b", null ]
];