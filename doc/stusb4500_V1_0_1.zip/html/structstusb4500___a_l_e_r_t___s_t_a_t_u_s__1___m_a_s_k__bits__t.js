var structstusb4500___a_l_e_r_t___s_t_a_t_u_s__1___m_a_s_k__bits__t =
[
    [ "CC_FAULT_STATUS_AL_MASK", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga406458faeffbe4f02afe7712d6e19dda", null ],
    [ "PORT_STATUS_AL_MASK", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gab67b8560412b3bb4fc459aba8db8ddbb", null ],
    [ "PRT_STATUS_AL_MASK", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#gacb4d7d1401dd5ad9986614d3ecfaa29d", null ],
    [ "reserved", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga4597862f7bb917229ec1048bfb09ca2b", null ],
    [ "reserved1", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga66e358abab298cc304586f0334dbdd54", null ],
    [ "reserved2", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga0ab833a6945e6999d741c728a7424149", null ],
    [ "TYPEC_MONITORING_STATUS_MASK", "group___s_t_u_s_b4500___r_e_g_e_d_e_f.html#ga6c3b65d6de27de51f418417fa36118f9", null ]
];